package com.compatibilidad.tasks;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;
import static com.compatibilidad.utils.Helpers.*;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.JavaScriptClick;
import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.actions.Switch;

import static com.compatibilidad.userinterfaces.LoginUserInterface.*;

public class Arpis implements Task {

	@Override
	public <T extends Actor> void performAs(T actor) {
		BrowseTheWeb.as(actor).getDriver().manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		waitSelenium(2);
		try {
			BrowseTheWeb.as(actor).getDriver().manage().window().maximize();
		} catch (Exception e) {
			e.printStackTrace();
		}
		waitSelenium(3);
		BrowseTheWeb.as(actor).getDriver().manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		//-----------------------------------------------------------------
		
		refreshNoRegister(actor);
		refreshNoRegister(actor);
		refreshNoRegister(actor);
		int wait =0;
		do {
			waitSelenium(1);
			wait = wait + 1;
		} while (!BUTTON_OPERACIONES.resolveFor(actor).isCurrentlyEnabled() && wait<10);
		
		actor.attemptsTo(Scroll.to(BUTTON_OPERACIONES),
				JavaScriptClick.on(BUTTON_OPERACIONES));
		waitSelenium(1);
		clienteUnico(actor);
		afiliaciones(actor);
	}
	
	public void clienteUnico(Actor actor) {
		actor.attemptsTo(Switch.toFrame(FRAME_MODULO.resolveFor(actor)),
				JavaScriptClick.on(BUTTON_CLIENTE_UNICO));
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		waitSelenium(1);
		JavascriptExecutor jse = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver();
		jse.executeScript("arguments[0].value='"+ "18" +"';", INPUT_REGISTROS.resolveFor(actor));
		waitSelenium(1);
		actor.attemptsTo(JavaScriptClick.on(BUTTON_INPUT_REGISTROS));
		waitSelenium(2);
		selectOptionJavaScript(actor, SELECT_PAGINA.resolveFor(actor), "3");
		System.out.println(BUTTON_DOCUMENTO.resolveFor(actor).getTextValue());
		actor.attemptsTo(JavaScriptClick.on(BUTTON_DOCUMENTO));
		waitSelenium(2);
		
	}
	
	
	public void afiliaciones(Actor actor) {
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)),
				JavaScriptClick.on(BUTTON_AFILIACIONES));
		waitSelenium(3);
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		waitSelenium(3);
		selectOptionJavaScript(actor, SELECT_CONDICION.resolveFor(actor), "MPS");
		selectOptionJavaScript(actor, SELECT_OPERADOR.resolveFor(actor), ">=");
		actor.attemptsTo(Enter.theValue("123").into(INPUT_CONDICION));
		//actor.attemptsTo(JavaScriptClick.on(BUTTON_BORRAR_CONDICIONES));
		
		selectOptionJavaScript(actor, SELECT_CAMPOS.resolveFor(actor), "Usuario registro");
		actor.attemptsTo(JavaScriptClick.on(BUTTON_DERECHA));
		waitSelenium(2);
		selectOptionJavaScript(actor, SELECT_CAMPOS_DOS.resolveFor(actor), "Usuario registro");
		actor.attemptsTo(JavaScriptClick.on(BUTTON_IZQUIERDA));
		waitSelenium(2);
	}
	
	
	 public void selectOptionJavaScript(Actor actor, WebElementFacade element,String value) {
	      JavascriptExecutor jexec = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver() ;
	      jexec.executeScript("var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }", element, value);
	  }
	
	public void refreshNoRegister(Actor actor) {
		if (LABEL_NO_REGISTRADO.resolveFor(actor).isCurrentlyVisible()) {
			BrowseTheWeb.as(actor).getDriver().navigate().refresh();
			waitSelenium(1);
			BrowseTheWeb.as(actor).getDriver().manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		}
	}
	
	public static Arpis inThePage() {
		return Tasks.instrumented(Arpis.class);
	}

}
