package com.compatibilidad.userinterfaces;

import org.openqa.selenium.By;
import net.serenitybdd.screenplay.targets.Target;

public class LoginUserInterface {

	public static final Target INPUT_USER = Target.the("input user").
			located(By.xpath("//input[@name='userName']"));
	public static final Target INPUT_PASSWORD = Target.the("input paswword").
			located(By.xpath("//input[@name='password']"));
	public static final Target BUTTON_SUBMIT = Target.the("button submit").
			located(By.xpath("//input[@name='submit']"));
	public static final Target BUTTON_SIGN_OFF = Target.the("button sign off").
			located(By.xpath("//td/a[contains(text(), 'SIGN-OFF')]"));
	
	//frame
	public static final Target IFRAME = Target.the("iframe").
			located(By.xpath("//iframe[@id='a077aa5e']"));
	public static final Target IMAGEN = Target.the("imagen").
			located(By.xpath("//html/body/a/img"));
	public static final Target BUTTON_HOME = Target.the("button home").
			located(By.xpath("//li/a[contains(text(), 'Home')]"));
	
	
	//arpis
	public static final Target LABEL_NO_REGISTRADO = Target.the("button no registrado").
			located(By.xpath("//td/font[contains(text(), 'no registrado')]"));
	public static final Target BUTTON_OPERACIONES = Target.the("button operaciones").
			located(By.xpath("//td/a[contains(text(), 'OPERACIONES')]"));
	public static final Target FRAME_MODULO = Target.the("frame modulo").
			located(By.xpath("//frame[@name='modulo']"));
	public static final Target BUTTON_CLIENTE_UNICO = Target.the("button cliente unico").
			located(By.xpath("//td/a[@title='Cliente Unico']"));
	public static final Target FRAME_FORMA = Target.the("frame forma").
			located(By.xpath("//frame[@name='forma']"));
	public static final Target INPUT_REGISTROS = Target.the("input registros").
			located(By.xpath("//input[@name='registros']"));
	public static final Target BUTTON_INPUT_REGISTROS = Target.the("button input registros").
			located(By.xpath("//td/img[contains(@src, 'imgOkVerde')]"));
	
	public static final Target SELECT_PAGINA = Target.the("select pagina").
			located(By.xpath("//select[@name='pagina']"));
	public static final Target BUTTON_REGISTROS_POR_PAGINA = Target.the("button registros por pagina").
			located(By.xpath("//td/a[@title='Cliente Unico']/ancestor::td/img"));
	public static final Target BUTTON_DOCUMENTO = Target.the("button documento").
			located(By.xpath("//table/tbody/tr[2]/td/a"));
	
	public static final Target BUTTON_AFILIACIONES = Target.the("button afiliaciones").
			located(By.xpath("//td/a[@title='Afiliaciones']"));
	public static final Target SELECT_CONDICION = Target.the("select condicion").
			located(By.xpath("//select[@name='field']"));
	public static final Target SELECT_OPERADOR = Target.the("select operador").
			located(By.xpath("//select[@name='operator']"));
	public static final Target INPUT_CONDICION= Target.the("input condicion").
			located(By.xpath("//input[@name='constraint']"));
	public static final Target BUTTON_BORRAR_CONDICIONES = Target.the("button borrar condiciones").
			located(By.xpath("//input[@name='Borrar']"));
	public static final Target SELECT_CAMPOS = Target.the("select campos").
			located(By.xpath("//select[@name='items']"));
	public static final Target BUTTON_DERECHA = Target.the("button derecha").
			located(By.xpath("//input[@name='toRight']"));
	public static final Target SELECT_CAMPOS_DOS = Target.the("select campos dos").
			located(By.xpath("//select[@name='fields']"));
	public static final Target BUTTON_IZQUIERDA = Target.the("button izquierda").
			located(By.xpath("//input[@name='toLeft']"));
	
	
	//autoliquidaciones
	public static final Target BUTTON_AUTOLIQUIDACIONES = Target.the("button autoliquidaciones").
			located(By.xpath("//a[@title='Autoliquidaciones']/ancestor::td/a/img"));
	public static final Target BUTTON_CONSULTA_LIQUIDACIONES = Target.the("button consulta liquidaciones").
			located(By.xpath("//a[text()='Consulta de Autoliquidaciones']"));
	public static final Target BUTTON_BUSQUEDA_AUTOLIQUIDACIONES = Target.the("button busqueda autoliquidaciones").
			located(By.xpath("//td[contains(text(), 'squeda')]"));
	public static final Target RADIO_AND = Target.the("radio and").
			located(By.xpath("//td/input[@value='AND']"));
	public static final Target RADIO_OR = Target.the("radio or").
			located(By.xpath("//td/input[@value='OR']"));
	public static final Target BUTTON_CANCLEAR_BUSQUEDA = Target.the("butoon cancelar busquweda ").
			located(By.xpath("//td/img[contains(@title, 'Cancelar')]"));
	
	
	// download excel afiliaciones
	public static final Target BUTTON_EXPORT_EXCEL = Target.the("button export excel").
			located(By.xpath("//td/input[@value='Exportar Excel']"));
	
	//recaudos recibo de caja
	public static final Target BUTTON_RECAUDOS = Target.the("button recaudos").
			located(By.xpath("//a[@title='Recaudos']/ancestor::td/a/img"));
	public static final Target BUTTON_RECIBOS_DE_CAJA = Target.the("button recibos de caja").
			located(By.xpath("//a[text()='Recibos de Caja']"));
	public static final Target BUTTON_CREAR_RECIBO = Target.the("button crear recibo").
			located(By.xpath("//td[contains(text(), 'Crear')]"));
	
	public static final Target BUTTON_CLIENTE_UNICO_RECIBOS = Target.the("button cliente unico recibos").located(By.xpath("//img[contains(@src, 'btnClienteUnico')]"));
	//public static final Target BUTTON_CLIENTE_UNICO_RECIBOS = Target.the("button cliente unico recibos").located(By.xpath("//img[contains(@src, 'btnClienteUnico')]/ancestor::a"));

	//public static final Target BUTTON_CLIENTE_UNICO_RECIBOS = Target.the("button cliente unico recibos").located(By.xpath("//a"));
}
