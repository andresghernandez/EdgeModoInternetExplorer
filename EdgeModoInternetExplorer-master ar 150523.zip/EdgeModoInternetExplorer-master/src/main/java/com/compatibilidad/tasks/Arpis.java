package com.compatibilidad.tasks;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;

import com.compatibilidad.interactions.WaitToLoad;

import static com.compatibilidad.utils.Helpers.*;
import static org.junit.Assert.assertTrue;

import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.JavaScriptClick;
import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.actions.Switch;
import static com.compatibilidad.userinterfaces.LoginUserInterface.*;

public class Arpis implements Task {

	@Override
	public <T extends Actor> void performAs(T actor) {
		BrowseTheWeb.as(actor).getDriver().manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		waitSelenium(2);
		try {
			BrowseTheWeb.as(actor).getDriver().manage().window().maximize();
		} catch (Exception e) {
			e.printStackTrace();
		}
		waitSelenium(3);
		BrowseTheWeb.as(actor).getDriver().manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		//-----------------------------------------------------------------
		
		refreshNoRegister(actor);
		//refreshNoRegister(actor);
		//refreshNoRegister(actor);
		int wait =0;
		do {
			waitSelenium(1);
			wait = wait + 1;
		} while (!BUTTON_OPERACIONES.resolveFor(actor).isCurrentlyEnabled() && wait<10);
		
		actor.attemptsTo(Scroll.to(BUTTON_OPERACIONES),
				JavaScriptClick.on(BUTTON_OPERACIONES));
		waitSelenium(3);
		//clienteUnico(actor);
		//afiliaciones(actor);
		//autoliquidaciones(actor);
		//downloadExcel(actor);
		recibosDeCaja(actor);//este funciona
		
	}
	
	public void recibosDeCaja2(Actor actor) {
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)));
		actor.attemptsTo(JavaScriptClick.on(BUTTON_RECAUDOS),
				JavaScriptClick.on(BUTTON_RECIBOS_DE_CAJA)); 
		waitSelenium(10);
		actor.attemptsTo(WaitToLoad.theMiliSeconds(10));
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		try {
			actor.attemptsTo(JavaScriptClick.on(BUTTON_CREAR_RECIBO));
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		

		//JavascriptExecutor executor = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver();
		//executor.executeScript("arguments[0].click();", BUTTON_CREAR_RECIBO.resolveFor(actor));
		
		actor.attemptsTo(Switch.toDefaultContext());
		
		//--------------------------------------------------------------------------------
		/*Set<String> handlesSet = BrowseTheWeb.as(actor).getDriver().getWindowHandles();
	    List<String> handlesList = new ArrayList<>(handlesSet);
	    System.out.println(handlesList.size());
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1));
	    waitSelenium(4);
	    String url= BrowseTheWeb.as(actor).getDriver().getCurrentUrl();
	    System.out.println(url);
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1)).close();
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(0));
	    actor.attemptsTo(Switch.toDefaultContext());
	    
	    
	    //------
		
		JavascriptExecutor jse = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver();
		jse.executeScript("window.open('');");*/
		Set<String> handlesSet = BrowseTheWeb.as(actor).getDriver().getWindowHandles();
	    List<String> handlesList = new ArrayList<>(handlesSet);
	    System.out.println(handlesList.size());
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1));
	    waitSelenium(5);
	    //BrowseTheWeb.as(actor).getDriver().get(url);
	    //BrowseTheWeb.as(actor).getDriver().get("https://alfacoreqa.segurosalfa.net:9443/arp/operaciones/Tesoreria/frmBuscarClienteAfiliacion.jsp");
	    
	    //BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1));
	    BrowseTheWeb.as(actor).getDriver().switchTo().defaultContent();
	    waitSelenium(10);
	    //----
	    System.out.println(BUTTON_CLIENTE_UNICO_RECIBOS.resolveFor(actor).isCurrentlyVisible());
	    actor.attemptsTo(WaitToLoad.theMiliSeconds(10),
	    		JavaScriptClick.on(BUTTON_CLIENTE_UNICO_RECIBOS));
	    waitSelenium(1);
	    //robot2();
	    //----
	    
	    //----------
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(0));
	    //--------------------------------------------------------------------------------
	    
	    actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)));
	    System.out.println();
	}
	
	
	public void recibosDeCaja(Actor actor) {
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)));
		actor.attemptsTo(JavaScriptClick.on(BUTTON_RECAUDOS),
				JavaScriptClick.on(BUTTON_RECIBOS_DE_CAJA)); 
		waitSelenium(10);
		actor.attemptsTo(WaitToLoad.theMiliSeconds(10));
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		/*try {
			actor.attemptsTo(JavaScriptClick.on(BUTTON_CREAR_RECIBO));
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		

		//JavascriptExecutor executor = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver();
		//executor.executeScript("arguments[0].click();", BUTTON_CREAR_RECIBO.resolveFor(actor));
		
		actor.attemptsTo(Switch.toDefaultContext());
		
		//--------------------------------------------------------------------------------
		Set<String> handlesSet = BrowseTheWeb.as(actor).getDriver().getWindowHandles();
	    List<String> handlesList = new ArrayList<>(handlesSet);
	    System.out.println(handlesList.size());
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1));
	    waitSelenium(4);
	    String url= BrowseTheWeb.as(actor).getDriver().getCurrentUrl();
	    System.out.println(url);
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1)).close();
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(0));
	    actor.attemptsTo(Switch.toDefaultContext());
	    
	    */
	    //------
		
		JavascriptExecutor jse = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver();
		jse.executeScript("window.open('');");
		Set<String> handlesSet = BrowseTheWeb.as(actor).getDriver().getWindowHandles();
	    List<String> handlesList = new ArrayList<>(handlesSet);
	    System.out.println(handlesList.size());
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1));
	    waitSelenium(5);
	    //BrowseTheWeb.as(actor).getDriver().get(url);
	    BrowseTheWeb.as(actor).getDriver().get("https://alfacoreqa.segurosalfa.net:9443/arp/operaciones/Tesoreria/frmBuscarClienteAfiliacion.jsp");
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1));
	    BrowseTheWeb.as(actor).getDriver().switchTo().defaultContent();
	    waitSelenium(10);
	    //----
	    System.out.println(BUTTON_CLIENTE_UNICO_RECIBOS.resolveFor(actor).isCurrentlyVisible());
	    actor.attemptsTo(WaitToLoad.theMiliSeconds(10),
	    		JavaScriptClick.on(BUTTON_CLIENTE_UNICO_RECIBOS));
	    waitSelenium(1);
	    //robot2();
	    //----
	    
	    //----------
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(0));
	    //--------------------------------------------------------------------------------
	    
	    actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)));
	    System.out.println();
	}
	
	public void robot2() {
		try {
            Thread.sleep(1000);
            Robot robot=new Robot();
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.mouseMove(608, 389);
            robot.mousePress(InputEvent.BUTTON1_MASK);
            robot.mouseRelease(InputEvent.BUTTON1_MASK);
        } catch (Exception e1) { //Excepcion de robot
            e1.printStackTrace();
        } 
		System.out.println("Salio robot");
	}
	
	public void downloadExcel(Actor actor) {
		waitSelenium(3);
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)));
		actor.attemptsTo(JavaScriptClick.on(BUTTON_AFILIACIONES));
		waitSelenium(3);
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		waitSelenium(3);
		actor.attemptsTo(JavaScriptClick.on(BUTTON_EXPORT_EXCEL));
		waitSelenium(5);
		robot();	
		waitSelenium(6);
		System.out.println("Descarga");
		nombreUltimaDescarga();
	}
	
	public void nombreUltimaDescarga() {
		String sCarpActProject = System.getProperty("user.dir") + "\\Downloads";
		String[] nombreUsuario = sCarpActProject.split("\\\\");
		String sCarpAct = nombreUsuario[0]+"\\"+nombreUsuario[1]+"\\"+ nombreUsuario[2]+"\\Downloads";
		File carpeta = new File(sCarpAct);
		File[] listaArchivos = carpeta.listFiles();
		Arrays.sort(listaArchivos, Comparator.comparingLong(File::lastModified).reversed());
		File lastFile = listaArchivos[0];
		
		System.out.println(lastFile.getName());
		
		
		boolean descargoArchivo = false;
		descargoArchivo = lastFile.getName().toUpperCase().contains("afiliacionesreporte".toUpperCase());
		
		String carpetaOrigen = sCarpAct +"\\"+lastFile.getName();
		String carpetaDestino = System.getProperty("user.dir") +"\\target\\site\\serenity\\"+lastFile.getName();
		
		Path origenPath = Paths.get(carpetaOrigen);
		Path destinoPath = Paths.get(carpetaDestino);
		
		if (descargoArchivo) {
			try {
			 	Files.move(origenPath, destinoPath, StandardCopyOption.REPLACE_EXISTING);
		    } catch (IOException e) {
		    	System.err.println(e);
		    }
		}
		System.out.println("Archivos");
	}
	
	public void robot() {
		try {
            Thread.sleep(1000);
            Robot robot=new Robot();
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_TAB);
            //robot.keyPress(KeyEvent.VK_SPACE);
            robot.keyPress(KeyEvent.VK_ENTER);
        } catch (Exception e1) { //Excepcion de robot
            e1.printStackTrace();
        } 
	}
	
	
	
	
	public void autoitDownload(Actor actor) throws IOException {
		 String[] dialog =  new String[]{ "C:\\save_ie_file.exe","Save to...","Save", "C:\\selenium_downloads\\" }; // path to exe, dialog title, save/cancel/run, path to save file.
		 Process pp1 = Runtime.getRuntime().exec(dialog);
		 actor.attemptsTo(JavaScriptClick.on(BUTTON_EXPORT_EXCEL));
		 pp1.destroy();
	}
	
	
	public void autoliquidaciones(Actor actor) {
		waitSelenium(1);
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)));
		actor.attemptsTo(JavaScriptClick.on(BUTTON_AUTOLIQUIDACIONES),
				JavaScriptClick.on(BUTTON_CONSULTA_LIQUIDACIONES)); 
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		actor.attemptsTo(JavaScriptClick.on(BUTTON_BUSQUEDA_AUTOLIQUIDACIONES));
		actor.attemptsTo(Switch.toDefaultContext());
		waitSelenium(3);
		//--------------------------------------------------------------------------------
		Set<String> handlesSet = BrowseTheWeb.as(actor).getDriver().getWindowHandles();
	    List<String> handlesList = new ArrayList<>(handlesSet);
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(1));
	    //----
	    actor.attemptsTo(JavaScriptClick.on(RADIO_OR),
	    		JavaScriptClick.on(RADIO_AND),
	    		JavaScriptClick.on(BUTTON_CANCLEAR_BUSQUEDA));
	    
	    //----
	    //BrowseTheWeb.as(actor).getDriver().close();
	    BrowseTheWeb.as(actor).getDriver().switchTo().window(handlesList.get(0));
	    //--------------------------------------------------------------------------------
	    
	    actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)));
	    actor.attemptsTo(JavaScriptClick.on(BUTTON_AUTOLIQUIDACIONES));
		System.out.println("Prueba");
	}
	
	
	
	
	
	
	public void clienteUnico(Actor actor) {
		actor.attemptsTo(Switch.toFrame(FRAME_MODULO.resolveFor(actor)),
				JavaScriptClick.on(BUTTON_CLIENTE_UNICO));
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		waitSelenium(1);
		JavascriptExecutor jse = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver();
		jse.executeScript("arguments[0].value='"+ "18" +"';", INPUT_REGISTROS.resolveFor(actor));
		waitSelenium(1);
		actor.attemptsTo(JavaScriptClick.on(BUTTON_INPUT_REGISTROS));
		waitSelenium(2);
		selectOptionJavaScript(actor, SELECT_PAGINA.resolveFor(actor), "3");
		System.out.println(BUTTON_DOCUMENTO.resolveFor(actor).getTextValue());
		actor.attemptsTo(JavaScriptClick.on(BUTTON_DOCUMENTO));
		waitSelenium(2);
		
	}
	
	
	public void afiliaciones(Actor actor) {
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_MODULO.resolveFor(actor)),
				JavaScriptClick.on(BUTTON_AFILIACIONES));
		waitSelenium(3);
		actor.attemptsTo(Switch.toDefaultContext(),
				Switch.toFrame(FRAME_FORMA.resolveFor(actor)));
		waitSelenium(3);
		selectOptionJavaScript(actor, SELECT_CONDICION.resolveFor(actor), "MPS");
		selectOptionJavaScript(actor, SELECT_OPERADOR.resolveFor(actor), ">=");
		actor.attemptsTo(Enter.theValue("123").into(INPUT_CONDICION));
		//actor.attemptsTo(JavaScriptClick.on(BUTTON_BORRAR_CONDICIONES));
		
		selectOptionJavaScript(actor, SELECT_CAMPOS.resolveFor(actor), "Usuario registro");
		actor.attemptsTo(JavaScriptClick.on(BUTTON_DERECHA));
		waitSelenium(2);
		selectOptionJavaScript(actor, SELECT_CAMPOS_DOS.resolveFor(actor), "Usuario registro");
		actor.attemptsTo(JavaScriptClick.on(BUTTON_IZQUIERDA));
		waitSelenium(2);
	}
	
	
	 public void selectOptionJavaScript(Actor actor, WebElementFacade element,String value) {
	      JavascriptExecutor jexec = (JavascriptExecutor) BrowseTheWeb.as(actor).getDriver() ;
	      jexec.executeScript("var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }", element, value);
	  }
	
	public void refreshNoRegister(Actor actor) {
		if (LABEL_NO_REGISTRADO.resolveFor(actor).isCurrentlyVisible()) {
			BrowseTheWeb.as(actor).getDriver().navigate().refresh();
			waitSelenium(1);
			BrowseTheWeb.as(actor).getDriver().manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		}
	}
	
	public static Arpis inThePage() {
		return Tasks.instrumented(Arpis.class);
	}

}
